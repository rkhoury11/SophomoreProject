package com.example.registrationtest;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.Toolbar;

import com.google.android.material.button.MaterialButton;

public class MainActivity extends AppCompatActivity {

    private Button button;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button = findViewById(R.id.button);
        button.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                new Hubpage();
            }
        });


        public void Hubpage(){
            Intent intent = new Intent((this, Hubpage.class));
            startActivity();
        }

        EditText username = (EditText) findViewById(R.id.username);

        MaterialButton regbtn = (MaterialButton) findViewById((R.id.signupbtn));

        regbtn.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username1 = username1 = username.getText().toString();
                Toast.makeText(MainActivity.this, "Username is", Toast.LENGTH_SHORT).show();
            }
        }));







    }
}